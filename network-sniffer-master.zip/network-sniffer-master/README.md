# 🌐 Network Sniffer  

## 📌 About the Project  
Network Sniffer is a powerful tool designed to monitor and analyze network traffic in real time. It helps capture packets, detect anomalies, and enhance security by identifying potential threats and unauthorized activities.  

---

## 🔑 Key Features  
✅ **Packet Capture** – Monitors and logs network packets  
✅ **Protocol Analysis** – Identifies TCP, UDP, ICMP, and more  
✅ **Real-time Monitoring** – Displays live network traffic  
✅ **Filtering** – Capture specific packets using custom filters  
✅ **Security Alerts** – Detects suspicious activities in the network  

---

## 🛠️ Tech Stack  
🔹 **Programming Language:** Python  
🔹 **Libraries:** Scapy, Socket, PyShark  
🔹 **Packet Analysis:** Wireshark Integration  
🔹 **GUI (Optional):** Tkinter / PyQt for visualization  

---

## 🔧 Installation & Setup
## 🔹 Clone the Repository
```bash
Copy
Edit
git clone https://github.com/yRaviKanthh/network-sniffer.git
```
### cd network-sniffer
🔹 Install Dependencies
```bash
Copy
Edit
pip install -r requirements.txt
```
### 🔹 Run the Application
```bash
Copy
Edit
python src/sniffer.py
🔗 View live network traffic in the terminal or GUI
```
---
🤝 Contributing
Contributions are welcome! Feel free to fork the repo, create a new branch, and submit a Pull Request. 😊

⭐ If you like this project, give it a star on GitHub! ⭐
